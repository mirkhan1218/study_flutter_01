enum AuthenticationStatus { authentication, unAuthenticated, unknown, init }
